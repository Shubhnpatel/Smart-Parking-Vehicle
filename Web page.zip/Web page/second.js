document.addEventListener('DOMContentLoaded', function() {
    const bookSlotButton = document.getElementById('bookSlotButton');
    const slotsContainer = document.getElementById('slotsContainer');
    const timeSelectionContainer = document.getElementById('timeSelectionContainer');
    const confirmBookingButton = document.getElementById('confirmBookingButton');
    const payNowButton = document.getElementById('payNowButton');
    let selectedSlot = null; // Variable to keep track of the selected slot

    // Handling slot booking
    bookSlotButton.addEventListener('click', function() {
        slotsContainer.innerHTML = ''; // Clear previous slots
        for (let i = 1; i <= 30; i++) {
            const slotButton = document.createElement('button');
            slotButton.textContent = `S${i}`;
            slotButton.classList.add('slot-button');
            slotButton.addEventListener('click', function() {
                if (selectedSlot) {
                    selectedSlot.style.backgroundColor = '#4CAF50'; // Reset previous selected slot color
                }
                this.style.backgroundColor = 'green'; // Set new selected slot color
                selectedSlot = this; // Update selected slot
            });
            slotsContainer.appendChild(slotButton);
        }
        slotsContainer.style.display = 'flex';
        timeSelectionContainer.style.display = 'block'; // Show the time selection container
    });

    // Confirming booking details
    confirmBookingButton.addEventListener('click', function() {
        const bookingDate = document.getElementById('bookingDate').value;
        const startTime = document.getElementById('startTime').value;
        const endTime = document.getElementById('endTime').value;

        if (!bookingDate || !startTime || !endTime) {
            alert('Please select a date and time range.');
            return;
        }

        if (selectedSlot) {
            // Display the Pay Now button only if a slot is selected and time is set
            payNowButton.style.display = 'block';
        } else {
            alert('Please select a slot first.');
        }
    });

    // Redirecting to third page on clicking 'Pay Now'
    payNowButton.addEventListener('click', function() {
        const bookingDate = document.getElementById('bookingDate').value; // in the format YYYY-MM-DD
        const startTime = document.getElementById('startTime').value; // in the format HH:MM
        const endTime = document.getElementById('endTime').value; // in the format HH:MM

        if (selectedSlot && bookingDate && startTime && endTime) {
            const formattedStartDate = new Date(bookingDate + 'T' + startTime);
            const formattedEndDate = new Date(bookingDate + 'T' + endTime);

            if (formattedStartDate < formattedEndDate) {
                const durationInMinutes = (formattedEndDate - formattedStartDate) / 60000;
                window.location.href = `third.html?duration=${durationInMinutes}`;
            } else {
                alert('End time must be after start time.');
            }
        } else {
            alert('Please complete the slot booking process.');
        }
    });
});
