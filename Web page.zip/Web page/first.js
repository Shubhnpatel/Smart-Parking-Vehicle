document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('parkingForm');
    const emailInput = document.getElementById('email');
    const mobileInput = document.getElementById('mobile');
    const carModelInput = document.getElementById('carModel');
    const nextButton = document.getElementById('nextButton');

    function validateForm() {
        nextButton.disabled = !emailInput.value || !mobileInput.value || !carModelInput.value;
    }

    emailInput.addEventListener('input', validateForm);
    mobileInput.addEventListener('input', validateForm);
    carModelInput.addEventListener('input', validateForm);

    form.addEventListener('submit', function(event) {
        event.preventDefault();
        // Add your logic here if needed to process form data
        // Redirect to the second page
        window.location.href = 'second.html';
    });
});
