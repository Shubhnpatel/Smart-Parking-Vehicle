document.addEventListener('DOMContentLoaded', function() {
    // Retrieve the duration from the URL
    const queryParams = new URLSearchParams(window.location.search);
    const durationInMinutes = parseInt(queryParams.get('duration'), 10);

    // Assuming the image URL will be set here
    const imageUrl = 'shubh gpay qr.jpg'; // Replace with your image URL

    // Validate duration and calculate total amount
    let totalAmount = 0;
    if (!isNaN(durationInMinutes)) {
        totalAmount = durationInMinutes + 30;
    } else {
        alert('Invalid booking details.');
        // Optional: Redirect back or handle invalid data appropriately
    }

    // Display the image
    const imageContainer = document.getElementById('imageContainer');
    const image = new Image();
    image.width = 330; // Width in pixels
    image.height = 480; // Height in pixels
    image.src = imageUrl;
    imageContainer.appendChild(image);

    // Display the amount
    const amountDisplay = document.getElementById('amountDisplay');

    // Create Font Awesome icon for Indian Rupee
    const rupeeIcon = document.createElement('i');
    rupeeIcon.className = 'fa-solid fa-indian-rupee-sign';

    // Append the icon and text to the amount display

    amountDisplay.appendChild(document.createTextNode(` Amount to be Paid: ₹${totalAmount}`));
});
